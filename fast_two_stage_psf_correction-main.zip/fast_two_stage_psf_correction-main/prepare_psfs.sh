unzip MATs_q0o0.zip
mv MATs_q0o0 psfs
rm MATs_q0o0.zip
